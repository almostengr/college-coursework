#include "csv.hpp"
#include <string>



void CSV::printStockSymbols(){


}          


void CSV::printDailyTotals(){
	

}


void CSV::prettyPrint(string symbolFile){


}