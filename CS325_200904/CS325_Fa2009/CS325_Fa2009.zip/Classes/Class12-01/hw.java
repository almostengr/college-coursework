import java.awt.*;
import javax.swing.*;

public class hw extends JApplet{
	public hw(){
	}

	public void init(){
		JLabel l = new JLabel("Hello World");
		add(l);
	}
}
