/*THIS IS CODE THAT WAS WRITTEN ON THE BOARD*/


double average(int a[]) throws StatisticsException{
	//THE ABOVE SPECIFIES WHAT TYPE OF EXCEPTION TO BE THROWN


	//IF THE LIST IS EMPTY, 
	if(!a.length)
		throw new StatisticsException("hi");
}


/*
boolean launchTheMissiles(){
	try{
		average([3,4,7]);

		average([]);
		//SINCE CALLED WITH AN EMPTY ARRAY, IT THROWS AN EXCEPTION
		//THEN IMMEDIATELY GO TO CATCH STATEMENT

		System.out.println("FOO");
	}

	catch(StatisticsException e){
		return false;
	}

	return true;

}
*/


boolean launchTheMissiles() throws Exception{
	average([]);
	System.out.print("HI");
}


MissionControl(){
	try {
		if(launchTheMissiles()){
		}
	}
	 
	catch(StatisticsException){ }
}




/*FINDING OUT HOW BIG AN ARRAY IS */


try{
	for(int i=0; ; i++){
		array[i];
	}
}
catch(Exception e){
	throw new Exception(" ");
}

finally{
	//IF CATCH IS NOT CALLED (THERE ARE NO EXCEPTIONS), THEN CALL FINALLY

	//PRINT IF NO EXCEPTION
	System.out.println("no exceptions");
	otherCode();
}



