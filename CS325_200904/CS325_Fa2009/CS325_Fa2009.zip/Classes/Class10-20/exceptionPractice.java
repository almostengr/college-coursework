public exceptionPractice() throw Exception{
	


} 
