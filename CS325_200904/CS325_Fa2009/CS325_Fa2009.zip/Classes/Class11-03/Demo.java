import java.awt.*;
import javax.swing.*;

public class Demo extends JFrame{
	
	BlankLabel blanklabel;	//CREATE A NEW BLANKLABEL TYPE OF BLANKLABEL

	public Demo (){
		setSize(500,500);
		setTitle("Demo for 11-03");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		blanklabel = new BlankLabel(Color.YELLOW);	//
		add(blanklabel);	//ADDING BLANKLABEL
	
		addMouseMotionListener(blanklabel);	//adds MOUSE MOTION LISTENER
	}

	public static void main(String args[]){
		Demo d = new Demo();
	}
}
