﻿'Kenneth Robinson
'Homework 4, Problem 2 
'CS 375     April 23, 2010

Module Module1

    Sub Main()
        Dim menuOption As String = "0"
        Dim decryptedText As String
        Dim encryptedText As String
        Dim convertCharacter As Char
        Dim convertNumber As Integer
        Dim stringPosition As Integer   '


        Console.WriteLine("Text Encryption Program based on ROT13 Encryption Method.")

        Do Until menuOption = "3"     'KEEP RUNNING PROGRAM UNTIL TOLD TO EXIT
            Console.WriteLine("-----MAIN MENU-----")
            Console.WriteLine(" 1) Encrypt text")   'DISPLAY MENU CHOICES
            Console.WriteLine(" 2) Decrypt text")
            Console.WriteLine(" 3) Exit")

            Console.Write("Choose an option from above: ")
            menuOption = Console.ReadLine

            If menuOption = "1" Then                'ENCRYPTER
                encryptedText = ""  'CLEAR STRING IN CASE OF PREVIOUS USAGE
                Console.WriteLine("")   'BLANK LINE
                Console.Write("Enter the text that you want to encrypt: ")
                decryptedText = Console.ReadLine    'TEXT IN RAW FORM

                Console.WriteLine("Encrypting...")
                Console.WriteLine("")   'BLANK LINE

                For stringPosition = 0 To (decryptedText.Length - 1)

                    'GET CHARACTER FROM STRING AT CURRENT POSITION
                    convertCharacter = decryptedText.Substring(stringPosition, 1)

                    convertNumber = AscW(convertCharacter)  'CONVERT CHARACTER TO NUMBER

                    'CONVERT NUBMERS FOR ENCRPYTING
                    If convertNumber >= 97 And convertNumber <= 109 Then
                        convertNumber = convertNumber + 13
                    ElseIf convertNumber >= 110 And convertNumber <= 122 Then
                        convertNumber = convertNumber - 13
                    ElseIf convertNumber >= 65 And convertNumber <= 77 Then
                        convertNumber = convertNumber + 13
                    ElseIf convertNumber >= 78 And convertNumber <= 90 Then
                        convertNumber = convertNumber - 13
                    End If

                    'ADD ENCRYPTED CHARACTER TO ENCRYPTED STRING AND CONVERT TO LETTER
                    encryptedText = encryptedText + ChrW(convertNumber)

                Next stringPosition     'END OF FOR LOOP

                Console.WriteLine(encryptedText)    'DISPLAY ENCRYPTED TEXT

                '''''END OF ENCRYPTION SECTION'''''

            ElseIf menuOption = "2" Then                'DECRYPTER
                decryptedText = ""      'CLEAR STRING IN CASE OF PREVIOUS USAGE
                Console.WriteLine("")   'BLANK LINE
                Console.Write("Enter the text that you want to decrypt: ")
                encryptedText = Console.ReadLine

                Console.WriteLine("Decrypting...")
                Console.WriteLine("")   'BLANK LINE

                For stringPosition = 0 To (encryptedText.Length - 1)

                    'GET CHARACTER FROM STRING AT CURRENT POSITION
                    convertCharacter = encryptedText.Substring(stringPosition, 1)

                    convertNumber = AscW(convertCharacter)  'CONVERT CHARACTER TO NUMBER

                    'CONVERT NUMBERS FOR ENCRYPTING
                    If convertNumber >= 97 And convertNumber <= 109 Then
                        convertNumber = convertNumber + 13
                    ElseIf convertNumber >= 110 And convertNumber <= 122 Then
                        convertNumber = convertNumber - 13
                    ElseIf convertNumber >= 65 And convertNumber <= 77 Then
                        convertNumber = convertNumber + 13
                    ElseIf convertNumber >= 78 And convertNumber <= 90 Then
                        convertNumber = convertNumber - 13
                    End If

                    'ADD DECRYPTED CHARACTER TO DECRYPTED STRING AND CONVERT TO LETTER
                    decryptedText = decryptedText + ChrW(convertNumber)

                Next stringPosition     'END OF FOR LOOP

                Console.WriteLine(decryptedText)    'DISPLAY DECRPYTED TEXT

                '''''END OF DECRYPTION SECTION'''''

            ElseIf menuOption = "3" Then                'EXIT PROGRAM
                Exit Sub
            Else
                Console.WriteLine("")   'BLANK LINE
                Console.WriteLine("You have picked an invalid option. Please select again.")    'ERROR MESSAGE
            End If

            Console.WriteLine("")   'BLANK LINE
            Console.WriteLine("")   'BLANK LINE
        Loop

    End Sub

End Module
