#ifndef __LIST__
#define __LIST__
#include "Iterator.hpp"


class List;
class ListIter;

class Node {
	int data;
	Node *next;
public:
	Node() {next = 0;}
	friend class List;
	friend class ListIter;
};



class List {
	Node *head;
	friend class ListIter;
public:
	List() {
		head = 0;
	}

	void add(int i) {
		Node *tmp = head;
		Node *n = new Node();
		n->data = i;
		if(head == 0) {
			head = n;
			return;
		}
		while(tmp->next) {
			tmp = tmp->next;
		}
		tmp->next = n;
	}

};

class ListIter: public Iterator {
	Node *current;
public:
	ListIter(List& list) {
		current = list.head;
	}
	bool hasMoreElements() {
		return current!=0;
	}

	int getValue() {
		return current->data;
	}

	void next() {
		if(current) {
			current = current->next;
		}
	}
};

#endif
