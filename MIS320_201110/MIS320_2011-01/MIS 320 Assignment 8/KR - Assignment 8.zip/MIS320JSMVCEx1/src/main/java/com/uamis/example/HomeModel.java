/*Kenneth Robinson
  MIS 320 Assignment 8
  April 12, 2011*/
package com.uamis.example;

public class HomeModel {
	private String message = "Here is my new message";	
	public String getMessage(){
		return message;
	}	
	public void setMessage(String message){
		this.message = message;
	}
}