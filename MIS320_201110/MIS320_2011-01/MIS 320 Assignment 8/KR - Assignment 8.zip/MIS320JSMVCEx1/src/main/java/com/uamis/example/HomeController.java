/*Kenneth Robinson
  MIS 320 Assignment 8
  April 12, 2011*/

  package com.uamis.example;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	private HomeModel model = new HomeModel();
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value="/", method=RequestMethod.GET)
	public ModelAndView home(String textdisplay) {
		logger.info("Welcome back");	
		ModelAndView modelandview = new ModelAndView("newhome");
		if (textdisplay == "" || textdisplay == null){
			model.setMessage("Default Text");
		}
		else{
			model.setMessage(textdisplay);
		}
		modelandview.addObject("message", model.getMessage());
		return modelandview;
	}
//	@RequestMapping(value="/", method=RequestMethod.GET)
//	public String home(){
//		logger.info("welcome back");
//		return "home";
//	}	
}